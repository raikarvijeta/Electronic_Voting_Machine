<?php
	session_start();
	
	function datepicker()
	{
		echo '<script>				
		$(document).ready(function() {

	 // assuming the controls you want to attach the plugin to 
	 // have the "datepicker" class set
	 $("#datepickertest").Zebra_DatePicker( {
		format: "Y-m-d",
		direction: true,
		disabled_dates: ["* * * 0,*"]
			});
		});
		</script>';
	}
	function scripts()
	{
		echo '	 
				<script type="text/javascript" src="addCand/js/jquery-1.11.1.js"></script>
				<script type="text/javascript" src="addCand/js/jquery-3.3.1.min.js"></script>
				<script type="text/javascript" src="addCand/js/bootstrap.min.js"></script>
				<script type="text/javascript" src="addCand/js/jquery.min.js"></script>
				
				
				<link href="addCand/css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>	
				
				
				<script type="text/javascript" src="addCand/js/jquery-ui.js"></script>
				<script type="text/javascript" src="addCand/js/zebra_datepicker.js"></script>
				<link rel="stylesheet" href="addCand/js/default.css" type="text/css">

    				<link rel="stylesheet" href="addCand/css/formValidation.css"/>
					
  					 <script type="text/javascript" src="addCand/js/formValidation.js"></script>
    				<script type="text/javascript" src="addCand/js/framework/bootstrap.js"></script>
							
		';
	}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	function register_header()
	{
	echo   ' <div class="h_bg">
			<div class="wrap">
				<div class="header">
					<div class="logo">
						<h1><img src="images/logo.png" alt=""></h1> 
					</div>
				</div>
			</div>
			</div>
		<div class="nav_bg">
			<div class="wrap">
			<ul class="nav">
				<li ><a href="index.php">Home</a></li>
				<li ><a href="About.php">About</a></li>
				<li ><a href="Login_form.php">Log in</a></li>
				<li class=""><a href="Doctors.php">Doctors</a></li>
				<li class="active"><a href="Register_form.php">Register</a></li>
				<div class="clear"></div>
			</ul>
			</div>
		</div>';	
	}

?>