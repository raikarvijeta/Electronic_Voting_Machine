<?php
include 'session.php';

	if(isset($_POST["submit"]))
	{
		

		$file = $_FILES['file']['tmp_name'];
		
		if($_FILES["file"]["size"] > 0)
		{
			
		$handle = fopen($file, "r");
		$c = 0;

		while(($filesop = fgetcsv($handle, 1000, ",")) !== false)
		{
			$c = $c + 1;

			if($c > 1){

				$ward = $filesop[6];
				$ElectionId = $filesop[1];
				$name = $filesop[2];
				$address = $filesop[3];
				$mobile = $filesop[4];
				$email = $filesop[5];
				

				$sql = "INSERT INTO voter(ElectionId,Name,address,mobile,email_id,ward_no,username)
 						VALUES('$ElectionId','$name','$address','$mobile','$email','$ward','$ElectionId')";
				$result = mysqli_query( $connection,$sql);
				//mysqli_stmt_execute($stmt);
				
				//$myvalue = 'Test me more';
				//$arr = explode(' ',trim($name));
				///echo $arr[1]; 
				
				//$ins_login="insert into logindetails(stud_id,course_id,username,password) values ('$rollno','$course_id','$rollno','$rollno')";
				//$result_login = mysqli_query( $connection,$ins_login);
			
			if($result)
			{
				echo "<script type=\"text/javascript\">
						alert(\"CSV File has been successfully Imported.\");
						window.location = \"Register_voters.php\"
					</script>";
			}
			else
			{	
				echo "ERROR".mysqli_error($connection);
			}
			}
	}
		
	}
		//header("refresh:5;url=studIndex.html");

	}
	

?>