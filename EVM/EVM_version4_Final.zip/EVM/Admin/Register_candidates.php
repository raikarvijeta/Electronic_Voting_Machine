<!DOCTYPE HTML>
<html>
<head> <!-- Done -->
	
		<?php 
		include 'session.php';
		include("include/html_include.php"); 
			//scripts();
			//validate();
		?>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

	<title>Candidate Registration</title>
	
	<!-- $title is to display title on nav bar -->
	<?php
		$title='Candidate Registration';
	?>
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/business-casual.min.css" rel="stylesheet">
	 <script>
         $(document).ready(function() {

			$('#register').click(function(){  
				   var image_name = $('#img_file').val();  
				   if(image_name == '')  
				   {  
						alert("Please Select Image");  
						return false;  
				   }  
				   else  
				   {  
						var extension = $('#img_file').val().split('.').pop().toLowerCase();  
						if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)  
						{  
							 alert('Invalid Image File');  
							 $('#img_file').val('');  
							 return false;  
						}  
				   }  
			});  

        });
		
		// to validate an image file
		function validateImg() {
			var image_name = document.forms["form"]["img_file"].value; 
				   if(image_name == '')  
				   {  
						alert("Please Select Image");  
						return false;  
				   }  
				   else  
				   {  
						var extension = document.forms["form"]["img_file"].value.split('.').pop().toLowerCase();  
						if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)  
						{  
							 alert('Invalid Image File');  
							 $('#img_file').val('');  
							 return false;  
						}  
				   }  
			
		}
	
		 
     </script>
	
	
</head>
<body style="background-color:rgba(47, 23, 16, 1);">
	<h1 class="site-heading text-center text-white d-none d-lg-block">
      <span class="site-heading-upper text-primary mb-3">EVM ONLINE</span>
      <span class="site-heading-lower">Vote From Home</span>
    </h1>
	 	<?php include("include/LoginName.php"); ?>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark py-lg-4" id="mainNav">
      <div class="container">
        <a class="navbar-brand text-uppercase text-expanded font-weight-bold d-lg-none" href="AdminProfile.php">EVM ONLINE</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav mx-auto">
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="AdminProfile.php">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="about.php">About</a>
            </li>
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="products.php">Parties</a>
            </li>
			
			<li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="startElec.php">Start Election</a>
            </li>
			<li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="result.php">Result</a>
            </li>
			
			<div class="dropdown nav-item px-lg-4">
			  <button class="dropbtn nav-link text-uppercase text-expanded">Voters</button>
			  <li class="dropdown-content">
				<a class="nav-link text-uppercase text-expanded" href="Register_voters.php">Register</a>
				<a class="nav-link text-uppercase text-expanded" href="viewVoters.php">View/Edit</a>
			  </li>
			</div>
			<div class="dropdown nav-item active px-lg-4">
			  <button class="dropbtn nav-link text-uppercase text-expanded">Candidates</button>
			  <li class="dropdown-content">
				<a class="nav-link text-uppercase text-expanded" href="Register_candidates.php">Register</a>
				<a class="nav-link text-uppercase text-expanded" href="view_candidates.php">View/Edit</a>
			  </li>
			</div>

			<li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="../logout.php">logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
	
	<?php //register_header(); ?>
	<div class="h_btm_bg" style="color:white;">	
		<div class="about-section" id="contact" style="">
		<section class="page-section clearfix">
			<div class="container">
				<div class="contact-header">
					<center><span style=""><h3>Candidate Registration</h3></span></center><br><br>
				</div>				
				<center>		
				<form id="defaultForm" name="form" method="post" class="form-horizontal" action="Register_candidates_action.php" enctype="multipart/form-data" onsubmit="return validateImg();">
               
					<div class="form-group">
                        <label class="col-lg-3 control-label" for="name">Name</label>
                        <div class="col-lg-4">
                            <input name="name" type="text" class="form-control input-md" style="width:300px" required>
                        </div>
                    </div>
					
					 <div class="form-group">
                        <label class="col-lg-3 control-label" for="party">Party</label>
                        <div class="col-lg-4">
                            <input name="party" type="text" class="form-control input-md" style="width:300px" required>
                        </div>
                    </div>
					
                    <div class="form-group">
                        <label class="col-lg-3 control-label" for="">Date of Election</label>
                        <div class="col-lg-5">
                            <input type="date" name="DOE" id="datepickertest" class="datepicker form-control input-md" style="width:300px"/>
                        </div>
                    </div>
                   
					<div class="form-group">
						<label class="col-lg-3 control-label" for="phone">Phone</label>
						<div class="col-lg-4">
							<input id="phone" name="phno" pattern="\d*" type="text" class="form-control input-md" style="width:300px" maxlength="10" required>
						</div>
					</div>
					
					<div class="form-group">
						<label class="col-lg-3 control-label" for="location">Location</label>
						<div class="col-lg-4">
							<textarea class="form-control"  name="location" value="" style="width:300px" required></textarea>
						</div>
					</div>
					
					<div class="form-group">
						<label class="col-lg-3 control-label" for="symbol">Symbol</label>
						<div class="col-lg-4">
							<input type="file" name="img_file" id="img_file" accept="image/*" /> 
						</div>
                    </div>
					<div class="form-group">
							<div class="col-lg-9 col-lg-offset-3">
								<button type="submit" id="register" class="btn btn-success" name="register" value="register">Register</button>
								<button type="reset" class="btn btn-info" name="" value="reset">Reset</button>
							</div>
					</div>
                </form>
				</center>
            </div>
		</section>
        </div>
    </div>
	
	<?php include("include/footer.php"); ?>
    
	<!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
	
</body>