<?php

include 'session.php';
include("include/html_include.php"); 
//scripts();

//$select_query = "SELECT 'symbol' FROM  'candidate' ";

$sql="SELECT * FROM  candidate";
/*
$sql = mysql_query($select_query) or die(mysql_error());	
while($row = mysql_fetch_array($sql,MYSQL_BOTH)){
*/
?>

<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>View Candidates</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/business-casual.min.css" rel="stylesheet">
	
	
	<!--- Scripts ------->
		<script language="JavaScript" type="text/javascript">
			function checkDelete()
			{
				return confirm('Are you sure you want to delete the entry ?');
			}	
		</script>

  </head>

  <body>

   <h1 class="site-heading text-center text-white d-none d-lg-block">
      <span class="site-heading-upper text-primary mb-3">EVM ONLINE</span>
      <span class="site-heading-lower">Vote From Home</span>
    </h1>
	 	<?php include("include/LoginName.php"); ?>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark py-lg-4" id="mainNav">
      <div class="container">
        <a class="navbar-brand text-uppercase text-expanded font-weight-bold d-lg-none" href="AdminProfile.php">EVM ONLINE</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav mx-auto">
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="AdminProfile.php">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="about.php">About</a>
            </li>
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="products.php">Parties</a>
            </li>
			
			<li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="startElec.php">Start Election</a>
            </li>
			<li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="result.php">Result</a>
            </li>
			
			<div class="dropdown nav-item px-lg-4">
			  <button class="dropbtn nav-link text-uppercase text-expanded">Voters</button>
			  <li class="dropdown-content">
				<a class="nav-link text-uppercase text-expanded" href="Register_voters.php">Register</a>
				<a class="nav-link text-uppercase text-expanded" href="viewVoters.php">View/Edit</a>
			  </li>
			</div>
			<div class="dropdown nav-item active px-lg-4">
			  <button class="dropbtn nav-link text-uppercase text-expanded">Candidates</button>
			  <li class="dropdown-content">
				<a class="nav-link text-uppercase text-expanded" href="Register_candidates.php">Register</a>
				<a class="nav-link text-uppercase text-expanded" href="view_candidates.php">View/Edit</a>
			  </li>
			</div>

			<li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="../logout.php">logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
		
		<?php
				$result = mysqli_query($connection,$sql);
				$num = mysqli_num_rows($result);
				if ($num > 0){
		?>
		<section class="page-section cta">
		<div class="container">
		<center><span style=""><h2>Candidate Details</h2></span></center><br><br>
		<div class="table-responsive">          
			<table class="table">
				<thead>
					<tr>
						<th>Symbol</th>
						<th>Name</th>
						<th>Party</th>
						<th>Date Of Election</th>
						<th>Phone NO</th>
						<th>Location</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
						<?php
							while ($row = mysqli_fetch_array($result))
							{
								//echo '<tr><td><img src="'.$row['symbol'].'"></td>' ;
								echo"<tr>";
									//echo"<div>";
									echo"<td>";?> <img src="<?php echo $row["symbol"] ?>" height="80" width="80"><?php echo"</td>";
									echo "<td>"; echo $row["name"]; echo"</td>";
									echo "<td>"; echo $row["party"]; echo"</td>";
									echo "<td>"; echo $row["DOE"]; echo"</td>";
									echo "<td>"; echo $row["phno"]; echo"</td>";
									echo "<td>"; echo $row["location"]; echo"</td>";
									echo "<td>";?><a href='update_candidates.php?id=<?php echo $row["c_id"];?>'>  <button style='background-color: #008CBA;' type='button' class='btn btn-primary btn-sm'>Update</button></a>
									<br>
									<br>
									<a href='del_candidates_action.php?id=<?php echo $row["c_id"];?>' onclick='return checkDelete()'> <button style='background-color: #008CBA;' type='button' class='btn btn-primary btn-sm'>Delete</button></a><?php echo"</td>";
									
								//echo"</div>";
								echo"</tr>";
								//echo"<br>";
							}
							?>
							</tbody>
			
							</table>
							</div>
							
						</div>
						</section>
						<?php
						}
						else {
						?>
						<section class="page-section cta">
						  <div class="container">
							<div class="row">
							  <div class="col-xl-9 mx-auto">
								<div class="cta-inner text-center rounded">
							<?php
							echo "<h2><center>No Candidate Records Found!!!</center></h2>";
						}
						?>
								</div>
							  </div>
							</div>
						  </div>
						</section>
						
	
    <section class="page-section about-heading">
     
    </section>

   <!-- <footer class="footer text-faded text-center py-5">
      <div class="container">
        <p class="m-0 small">Copyright &copy; EVM 2018</p>
      </div>
    </footer>
	-->
	<?php include("include/footer.php"); ?>
    <!-- Bootstrap core JavaScript -->
	
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

  <!-- Script to highlight the active date in the hours list -->
  <script>
    $('.list-hours li').eq(new Date().getDay()).addClass('today');
  </script>

</html>





