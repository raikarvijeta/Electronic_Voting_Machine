<!DOCTYPE html>
<?php
include 'session.php';
?>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>EVM</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/business-casual.min.css" rel="stylesheet">
	<style>
	.mb-0{
		text-align:justify;
	}
	</style>
  </head>

  <body>

    <h1 class="site-heading text-center text-white d-none d-lg-block">
      <span class="site-heading-upper text-primary mb-3">EVM ONLINE</span>
      <span class="site-heading-lower">Vote From Home</span>
    </h1>
	 	<?php include("include/LoginName.php"); ?>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark py-lg-4" id="mainNav">
      <div class="container">
        <a class="navbar-brand text-uppercase text-expanded font-weight-bold d-lg-none" href="AdminProfile.php">EVM ONLINE</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav mx-auto">
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="AdminProfile.php">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="about.php">About</a>
            </li>
            <li class="nav-item active px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="products.php">Parties</a>
            </li>
			
			<li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="startElec.php">Start Election</a>
            </li>
			<li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="result.php">Result</a>
            </li>
			
			<div class="dropdown nav-item px-lg-4">
			  <button class="dropbtn nav-link text-uppercase text-expanded">Voters</button>
			  <li class="dropdown-content">
				<a class="nav-link text-uppercase text-expanded" href="Register_voters.php">Register</a>
				<a class="nav-link text-uppercase text-expanded" href="viewVoters.php">View/Edit</a>
			  </li>
			</div>
			<div class="dropdown nav-item px-lg-4">
			  <button class="dropbtn nav-link text-uppercase text-expanded">Candidates</button>
			  <li class="dropdown-content">
				<a class="nav-link text-uppercase text-expanded" href="Register_candidates.php">Register</a>
				<a class="nav-link text-uppercase text-expanded" href="view_candidates.php">View/Edit</a>
			  </li>
			</div>

			<li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="../logout.php">logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <section class="page-section">
      <div class="container">
        <div class="product-item">
          <div class="product-item-title d-flex">
            <div class="bg-faded p-5 d-flex ml-auto rounded">
              <h2 class="section-heading mb-0">
                <span class="section-heading-upper"></span>
                <span class="section-heading-lower">Bharatiya Janata Party</span>
              </h2>
            </div>
          </div>
          <img class="product-item-img mx-auto d-flex rounded img-fluid mb-3 mb-lg-0" src="img/BJP.jpg" alt="">
          <div class="product-item-description d-flex mr-auto">
            <div class="bg-faded p-5 rounded">
              <p class="mb-0">The Bharatiya Janata Party; translation: Indian People's Party; abbr. BJP) is one of the two major political parties in India, along with the Indian National Congress.As of 2016, it is the country's largest political party in terms of representation in the national parliament and state assemblies, and it is the world's largest party in terms of primary membership. The BJP is a right-wing party,with close ideological and organisational links to the Hindu nationalist Rashtriya Swayamsevak Sangh.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="page-section">
      <div class="container">
        <div class="product-item">
          <div class="product-item-title d-flex">
            <div class="bg-faded p-5 d-flex mr-auto rounded">
              <h2 class="section-heading mb-0">
                <span class="section-heading-upper"></span>
                <span class="section-heading-lower">Indian National Congress</span>
              </h2>
            </div>
          </div>
          <img class="product-item-img mx-auto d-flex rounded img-fluid mb-3 mb-lg-0" src="img/congress.png" alt="">
          <div class="product-item-description d-flex ml-auto">
            <div class="bg-faded p-5 rounded">
              <p class="mb-0">The Indian National Congress (INC, often called Congress) is a broadly based political party in India. Founded in 1885, it was the first modern nationalist movement to emerge in the British Empire in Asia and Africa.From the late 19th century, and especially after 1920, under the leadership of Mahatma Gandhi, Congress became the principal leader of the Indian independence movement, with over 15 million members and over 70 million participants.Congress led India to independence from Great Britain,and powerfully influenced other anti-colonial nationalist movements in the British Empire.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <?php include("include/footer.php"); ?>


    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
