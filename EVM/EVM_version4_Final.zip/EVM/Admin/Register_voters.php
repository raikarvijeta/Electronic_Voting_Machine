<?php
include 'session.php';
?>
<html>
<head>
	<title>Register Voter</title>
	
	<!-- $title is to display title on nav bar -->
	<?php
		$title='Register Voter';
	?>
	
	
	<!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	
	 <link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i" rel="stylesheet">
	
	 <link href="css/business-casual.min.css" rel="stylesheet">
	 
	<!-- Email Id Validation Script-->
	<script>
		function validateEmail() {
			var x = document.forms["form"]["email"].value;
			var atpos = x.indexOf("@");
			var dotpos = x.lastIndexOf(".");
			if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length) {
				alert("Not a valid e-mail address");
				return false;
			}
		}
	</script>
	 
	 
	 
</head>
<body style="color:white;">
	
	<h1 class="site-heading text-center text-white d-none d-lg-block">
      <span class="site-heading-upper text-primary mb-3">EVM ONLINE</span>
      <span class="site-heading-lower">Vote From Home</span>
    </h1>
	 	<?php include("include/LoginName.php"); ?>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark py-lg-4" id="mainNav">
      <div class="container">
        <a class="navbar-brand text-uppercase text-expanded font-weight-bold d-lg-none" href="AdminProfile.php">EVM ONLINE</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav mx-auto">
            <li class="nav-item active px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="AdminProfile.php">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="about.php">About</a>
            </li>
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="products.php">Parties</a>
            </li>
			
			<li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="startElec.php">Start Election</a>
            </li>
			<li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="result.php">Result</a>
            </li>
			
			<div class="dropdown nav-item active px-lg-4">
			  <button class="dropbtn nav-link text-uppercase text-expanded">Voters</button>
			  <li class="dropdown-content">
				<a class="nav-link text-uppercase text-expanded" href="Register_voters.php">Register</a>
				<a class="nav-link text-uppercase text-expanded" href="viewVoters.php">View/Edit</a>
			  </li>
			</div>
			<div class="dropdown nav-item px-lg-4">
			  <button class="dropbtn nav-link text-uppercase text-expanded">Candidates</button>
			  <li class="dropdown-content">
				<a class="nav-link text-uppercase text-expanded" href="Register_candidates.php">Register</a>
				<a class="nav-link text-uppercase text-expanded" href="view_candidates.php">View/Edit</a>
			  </li>
			</div>

			<li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="../logout.php">logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

	<div class="h_btm_bg">	
		<div class="about-section" id="contact" style="">
			<div class="container">
			<section class="page-section clearfix">
				<div class="contact-header">
					<center><span style=""><h3>Voters Registration</h3></span></center><br><br>
				</div>	

				<div class="container">
					<form style="float:left;" class="form-horizontal well" action="uploadExcel.php" method="post" name="upload_excel" enctype="multipart/form-data">
							<fieldset>
								<div class="control-group">
									<div class="control-label">
										<label>Upload CSV file:</label>
									</div>
									<div class="controls">
										<input type="file" name="file" id="file" class="input-large">
									</div>
								</div>
								
								<div class="control-group">
									<div class="controls"><br>
									<button type="submit" id="submit" name="submit" class="btn btn-primary button-loading" data-loading-text="Loading...">Upload</button><br><br>
									</div>
								</div>
							</fieldset>
					</form>
				<div>
						
				<center>			
				<form class="form-horizontal" action="act-register.php" method="post" name="form" onsubmit="return validateEmail();">
					<div class="form-group">
                        <label style="margin-left:-250px;" class="col-lg-3 control-label" for="electionId">Enter election ID</label>
                        <div class="col-lg-4">
							<input type="text" name="id" class="form-control input-md" style="width:300px" required maxlength="10"/>
						</div>
                    </div>
					
					<div class="form-group">
                        <label style="margin-left:-280px;" class="col-lg-3 control-label" for="electionId">Enter name</label>
                        <div class="col-lg-4">
							<input type="text" name="name" class="form-control input-md" style="width:300px" required />
						</div>
                    </div>
					
					<div class="form-group">
                        <label class="col-lg-3 control-label" for="electionId">Enter address</label>
                        <div class="col-lg-4">
							<textarea name="address" class="form-control" style="width:300px" required></textarea>
							
						</div>
                    </div>
						
					<div class="form-group">
                        <label class="col-lg-3 control-label" for="electionId">Enter mobile</label>
                        <div class="col-lg-4">	
							<input type="text" name="mobile" pattern="\d*" class="form-control input-md" style="width:300px" required maxlength="10" />
						</div>
                    </div>

					<div class="form-group">
                        <label class="col-lg-3 control-label" for="electionId">Enter email ID</label>
                        <div class="col-lg-4">		
							<input type="text" name="email" class="form-control input-md" style="width:300px" required />
						</div>
                    </div>

					<div class="form-group">
                        <label class="col-lg-3 control-label" for="electionId">Enter ward No</label>
                        <div class="col-lg-4">	
							<input type="number" name="wardno" class="form-control input-md" style="width:300px" required />
						</div>
                    </div>	
					<!-- enter voted<input type="voted" name="voted" required></br></br> -->
					<div class="form-group">
						<div class="col-lg-9 col-lg-offset-3">
							<button class="btn btn-success" type="submit" name="submit" value="submit" >Submit</button>
							<button type="reset" class="btn btn-info" name="" value="reset">Reset</button>
						</div>
                    </div>	
					
					<?php
					   if (isset($_GET['msg']))
						{
							$message = $_GET['msg'];
							if($message == 1){
								//echo "<span style='color:green'>sucessfully inserted !</span>";
								/*echo '<script language="javascript">';
								echo 'alert("message successfully sent");';
								echo '</script>';
								*/
							}
						
						}
					?>
				</form>
				</center>
			</section>
			</div>
		</div>
	</div>
	
	<!-- Bootstrap core JavaScript -->
	<?php include("include/footer.php");?>
    <script src="vendor/jquery/jquery.min.js"></script>
	
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>

