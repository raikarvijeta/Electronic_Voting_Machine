<?php
/*
$con = mysqli_connect("localhost","root", "", "elections")
or die("failed to connect the server" .mysqli_connect_error());
*/ 
include "session.php";

$electionID= mysqli_real_escape_string($connection ,$_POST['id']);
$name=mysqli_real_escape_string($connection ,$_POST['name']);
$address=mysqli_real_escape_string($connection ,$_POST['address']);
$mobile=mysqli_real_escape_string($connection ,$_POST['mobile']);
$emailID=mysqli_real_escape_string($connection ,$_POST['email']);
$wardno=mysqli_real_escape_string($connection ,$_POST['wardno']);
//$voted=mysqli_real_escape_string($con ,$_POST['voted']);
$voted=0;
 	$query= "INSERT INTO voter(ElectionId,Name,address,mobile,email_id,ward_no,username)
 						VALUES('$electionID','$name','$address','$mobile','$emailID','$wardno','$electionID')";

 	if(!mysqli_query($connection, $query))
 		{
 			echo "ERROR".mysqli_error($connection);
 		}
 		else
 		{
 			//header("Location: Register_voters.php");
			echo '<script language="javascript">';
			echo 'alert("Sucessfully Inserted !");';
			echo '</script>';
			header( "refresh:1; url=Register_voters.php" );
 		}
 		
 ?>
 