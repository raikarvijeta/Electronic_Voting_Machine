<?php
	
	include "session.php";
	
		//$sql2 = "delete from candidate";
		//mysqli_query($connection,$sql2);
	
		if(isset($_POST["start"]))  
		{
			$name =	$_POST['name']; 
			$SD =$_POST['SD']; 
			$ST =	$_POST['ST']; 		
			$ET =	$_POST['ET'];
			
			$sql = "INSERT INTO `startelection`(`ElecName`, `start_date`, `start_time`,`end_time`) VALUES 
									('$name','$SD','$ST','$ET')";
			mysqli_query($connection,$sql);
			
			$update_voted = "update voter set voted='0'";
			mysqli_query($connection,$update_voted);
			?>
			<script>
			window.location.href='startElec.php';
			alert("Election Started Successfully!");
			</script>
			<?php
		}
?>