<!DOCTYPE html>
<?php
include 'session.php';
?>
<html>
	<head>

		<title> Votes</title>
		
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="">
		<meta name="author" content="">

		<!-- Bootstrap core CSS -->
		<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

		<!-- Custom fonts for this template -->
		<link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i" rel="stylesheet">

		<!-- Custom styles for this template -->
		<link href="css/business-casual.min.css" rel="stylesheet">

 		<script
		  src="https://code.jquery.com/jquery-3.2.1.js"
		  integrity="sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE="
		  crossorigin="anonymous"></script>
	    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
		
		<script>
				
			//ajax method used on whole data of process_ajax.php
			function ajax_func() {

				xmlhttp = new XMLHttpRequest();

				xmlhttp.onreadystatechange = function () {
					if(xmlhttp.readyState == 4 && xmlhttp.status == 200) {
						document.getElementById('ret_data').innerHTML = xmlhttp.responseText;
					}
				}

				xmlhttp.open('GET', 'votesAjax.php', true);
				xmlhttp.send();
			}
			
			function CastVote(ID){
				xmlhttp.onreadystatechange = function () {
					if(xmlhttp.readyState == 4 && xmlhttp.status == 200) {
						document.getElementById('ret_data').innerHTML = xmlhttp.responseText;
					}
				}				
					
				var ans = confirm ("Are you sure?");
				if (ans){
					xmlhttp.open('GET','votesAjax.php?ID='+ID,true);
					xmlhttp.send();
					alert('Your Vote has been recorded successfully');
					window.location.href='UserProfile.php';
				}
			}
		</script>
		<style>
			table{
		width:100%;
	
		color:white;
		border-style:double;
		border-width:5px;  
	}
		</style>
</head>

<body onload="ajax_func();">
	<h1 class="site-heading text-center text-white d-none d-lg-block">
      <span class="site-heading-upper text-primary mb-3">EVM ONLINE</span>
      <span class="site-heading-lower">Vote From Home</span>
    </h1>
	<?php include("include/LoginName.php"); ?>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark py-lg-4" id="mainNav">
      <div class="container">
        <a class="navbar-brand text-uppercase text-expanded font-weight-bold d-lg-none" href="UserProfile.php">EVM ONLINE</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav mx-auto">
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="UserProfile.php">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="about.php">About</a>
            </li>
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="products.php">Parties</a>
            </li>
			
			<li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="result.php">Results</a>
            </li>
			
			<li class="nav-item active px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="Votes.php">Cast Your Vote</a>
            </li>

			<li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="../logout.php">logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
<?php

	$get_date="select * from startelection";
	$elecDetails=mysqli_query($connection,$get_date);
	$row_elec = mysqli_fetch_assoc($elecDetails);
	$start=$row_elec['start_date'];
	$ST=$row_elec['start_time'];
	$ET=$row_elec['end_time'];
	
	if($elecDetails){
	
		$timezone = new DateTimeZone("Asia/Kolkata" );
		$date = new DateTime();
		$date->setTimezone($timezone );
		//$cur_date = $date->format( 'Y-m-d H:i:s' ); "<br>";
		$cur_date = $date->format( 'Y-m-d' );
		$cur_time = $date->format( 'H:i:s' );
		//echo $cur_time;
		
		if($start==$cur_date){
			if(($ST<=$cur_time)&&($ET>=$cur_time)){
			$login=$login_session;
			$user="select * from voter where username='$login'";
			$userDetails=mysqli_query($connection,$user);
			$row = mysqli_fetch_assoc($userDetails);
			$voted=$row['voted'];
			if($voted=='0'){
			
			?>
					<br><h1>CAST YOUR VOTE</h1><br>
					<table class="table table-bordered text-center">
						<thead>
							<tr>
								<th>Id</th>
								<th>Symbol</th>
								<th>Candidate Name</th>
								<th>Edit Options</th>
							</tr>
						</thead>
						<tbody id="ret_data">
						


							
						</tbody>
					</table>
		<?php	
		}
		else{
		?>
		<section class="page-section cta">
		  <div class="container">
			<div class="row">
			  <div class="col-xl-9 mx-auto">
				<div class="cta-inner text-center rounded">
				<?php
			echo "<h2>Your vote is already recorded</h2>";
		}
		}
		}
	else { 
	?>
	<section class="page-section cta">
      <div class="container">
        <div class="row">
          <div class="col-xl-9 mx-auto">
            <div class="cta-inner text-center rounded">
			<?php
		echo "<h2>No Elections!!!</h2>";
	
	}}
	?>
			</div>
          </div>
        </div>
      </div>
    </section>
	
	
	<?php include("include/footer.php"); ?>


    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>